<?php
if (!defined('INCLUDED_FROM_INDEX')) {
    die('Direct access not allowed');
}
header('Content-Type: text/html; charset=UTF-8');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include '../PHPMailer/src/Exception.php';
include '../PHPMailer/src/PHPMailer.php';
include '../PHPMailer/src/SMTP.php';

function sendMail($subject, $body) {
    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->CharSet = 'UTF-8';
        $mail->addCustomHeader('Content-Type: text/html; charset=UTF-8');
        $mail->Host        = getenv('SMTP_HOST');
        $mail->SMTPAuth    = true;
        $mail->Username    = getenv('SMTP_USERNAME');
        $mail->Password    = getenv('SMTP_PASSWORD');
        $mail->SMTPSecure  = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port        = getenv('SMTP_PORT');
        $mail->setFrom(getenv('MAIL_FROM'), '법률사무소 대한');
        $mail->addAddress(getenv('MAIL_TO'), '법률사무소 대한');
        $mail->isHTML(true);
        $mail->Subject     = $subject;
        $mail->Body        = $body;
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>