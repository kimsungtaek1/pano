<?php
// CORS 헤더 설정
$allowed_origins = [
'https://lez062802.mycafe24.com/',
'https://lez062803.mycafe24.com/',
'https://lez062804.mycafe24.com/',
'https://lez062805.mycafe24.com/',
'https://lez062806.mycafe24.com/',
'https://lez062807.mycafe24.com/',
'https://lez062808.mycafe24.com/',
'https://lez062809.mycafe24.com/',
'https://lez062810.mycafe24.com/',
'https://lez062811.mycafe24.com/',
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';

if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: $origin");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Allow-Headers: Content-Type");
    header("Access-Control-Max-Age: 86400"); // 24시간
}

// OPTIONS 요청에 대한 응답
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(204);
    exit();
}

// 콘텐츠 타입 설정
header("Content-Type: application/json; charset=UTF-8");

require_once 'admin/config.php';  // PDO 연결을 포함하는 설정 파일

// POST 데이터 받기
$inflow_page = $_POST['inflow_page'] ?? '';
$inflow_name = $_POST['inflow_name'] ?? '';
$category = $_POST['category'] ?? '';
$phone = $_POST['phone'] ?? '';
$name = $_POST['name'] ?? '';
$consultant = $_POST['consultant'] ?? 0;
$birth_date = $_POST['birth_date'] ?? '';
$debt_amount = $_POST['debt_amount'] ?? '';
$region = $_POST['region'] ?? '';
$consultation_time = $_POST['consultation_time'] ?? '';
$content = $_POST['content'] ?? '';
$ip = $_POST['ip'] ?? '';
$user_agent = $_POST['user_agent'] ?? '';
$device_type = $_POST['device_type'] ?? '';

// 데이터베이스에 삽입
try {
    $stmt = $pdo->prepare("INSERT INTO assignments (datetime, inflow_page, inflow, category, phone, name, consultant, birth_date, debt_amount, region, consultation_time, content, sms_sent, ip, user_agent, device_type) VALUES (NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)");
    
    $result = $stmt->execute([
        $inflow_page,
        $inflow_name,
        $category,
        $phone,
        $name,
        $consultant,
        $birth_date,
        $debt_amount,
        $region,
        $consultation_time,
        $content,
		$ip,
		$user_agent,
		$device_type
    ]);

    if ($result) {
        echo json_encode(['success' => true, 'message' => '데이터가 성공적으로 삽입되었습니다.']);
    } else {
        echo json_encode(['success' => false, 'message' => '데이터 삽입 중 오류가 발생했습니다.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => '데이터베이스 오류: ' . $e->getMessage()]);
}