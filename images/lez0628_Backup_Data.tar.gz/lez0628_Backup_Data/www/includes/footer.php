    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">PANO</div>
                <div class="footer-info">
                    <p>법무법인 파노 | 대표변호사 홍길동 | 사업자등록번호 123-45-67890</p>
                    <p>서울특별시 중구 퇴계로 97 고려대연건물 10층 | 전화: 02-1234-5678 | 팩스: 02-1234-5679</p>
                    <p>© Copyright 2024 Law Firm PANO. All Rights Reserved.</p>
                </div>
                <div class="footer-links">
                    <a href="#">이용약관</a>
                    <a href="#">개인정보처리방침</a>
                    <a href="#">이메일무단수집거부</a>
                </div>
            </div>
        </div>
    </footer>
    <button id="scrollTop" onclick="scrollToTop()">↑</button>
    <script src="/js/script.js"></script>
</body>
</html>
